# LD37
A weekend filled with lots of goofs and gaffs, but most of all, glucose.
MEMES.
